const express = require("express");
const router = express.Router();
const {
    bookAppointment,
    getAppointments,
    addPrescription,
    addFeedback
} = require("../controllers/appointmentController");

router.post("/book", bookAppointment);
router.get("/", getAppointments);
router.put("/:id/prescription", addPrescription);
router.put("/:id/feedback", addFeedback);

module.exports = router;
