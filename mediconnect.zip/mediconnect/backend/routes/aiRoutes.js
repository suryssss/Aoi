const express = require("express");
const router = express.Router();
const { chat, analyzeSymptoms } = require("../controllers/aiController");

router.post("/chat", chat);
router.post("/analyze-symptoms", analyzeSymptoms);

module.exports = router;
