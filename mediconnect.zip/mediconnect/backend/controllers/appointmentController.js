const Appointment = require("../models/Appointment");
const Doctor = require("../models/Doctor");

// Book Appointment
exports.bookAppointment = async (req, res) => {
    try {
        const { patientName, doctorName, date, time } = req.body;

        if (!patientName || !doctorName || !date || !time) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const newAppointment = await Appointment.create({
            patientName,
            doctorName,
            date,
            time,
            createdAt: new Date()
        });

        res.status(201).json({
            message: "Appointment booked successfully",
            appointment: newAppointment
        });

    } catch (error) {
        res.status(500).json({ message: "Server error while booking appointment" });
    }
};


// Get All Appointments (for future dash)
// Get Appointments by Doctor or Patient
exports.getAppointments = async (req, res) => {
    try {
        const { doctorName, patientName } = req.query;

        let filter = {};

        if (doctorName) {
            filter.doctorName = doctorName;
        }

        if (patientName) {
            filter.patientName = patientName;
        }

        const appointments = await Appointment.find(filter).sort({ createdAt: -1 });

        res.json(appointments);

    } catch (error) {
        res.status(500).json({ message: "Error fetching appointments" });
    }
};

// Add Prescription
exports.addPrescription = async (req, res) => {
    try {
        const appointmentId = req.params.id;
        const { prescription, medicines } = req.body;

        const updatedAppointment = await Appointment.findByIdAndUpdate(
            appointmentId,
            { prescription, medicines },
            { new: true }
        );

        if (!updatedAppointment) {
            return res.status(404).json({ message: "Appointment not found" });
        }

        res.json({
            message: "Prescription added successfully",
            appointment: updatedAppointment
        });

    } catch (error) {
        res.status(500).json({ message: "Error adding prescription" });
    }
};

// Add Feedback
exports.addFeedback = async (req, res) => {
    try {
        const appointmentId = req.params.id;
        const { rating, review } = req.body;

        const updatedAppointment = await Appointment.findByIdAndUpdate(
            appointmentId,
            { feedback: { rating, review } },
            { new: true }
        );

        if (!updatedAppointment) {
            return res.status(404).json({ message: "Appointment not found" });
        }

        const doctorName = updatedAppointment.doctorName;
        // Find all appointments for this doctor that have non-null feedback.rating
        const allFeedbacks = await Appointment.find({ doctorName, "feedback.rating": { $exists: true } });

        if (allFeedbacks.length > 0) {
            const sum = allFeedbacks.reduce((acc, curr) => acc + curr.feedback.rating, 0);
            const avgRating = (sum / allFeedbacks.length).toFixed(1);
            
            await Doctor.findOneAndUpdate({ name: doctorName }, { rating: avgRating });
        }

        res.json({
            message: "Feedback added successfully",
            appointment: updatedAppointment
        });

    } catch (error) {
        console.error("Error adding feedback:", error);
        res.status(500).json({ message: "Error adding feedback" });
    }
};
