const Groq = require("groq-sdk");

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

exports.chat = async (req, res) => {
    const { message } = req.body;

    if (!message) {
        return res.status(400).json({ error: "Message is required" });
    }

    try {
        const completion = await groq.chat.completions.create({
            model: "llama-3.1-8b-instant",
            messages: [
                {
                    role: "system",
                    content: `You are MediBot, a friendly and knowledgeable AI health assistant for MediConnect, a doctor appointment booking platform.

Your role is to:
- Help patients understand their symptoms and suggest which type of specialist doctor to consult
- Provide general health advice and wellness tips
- Help patients prepare questions for their doctor visits
- Explain common medical terms in simple language
- Remind patients about the importance of professional medical care

Important rules:
- Never diagnose diseases or prescribe medications
- Always encourage consulting a real doctor for serious conditions
- Keep responses concise (3-5 sentences max)
- Be empathetic and reassuring
- If someone mentions an emergency (chest pain, difficulty breathing, severe bleeding), immediately tell them to call emergency services (108 in India)
- You can suggest which specialist to visit based on symptoms`
                },
                {
                    role: "user",
                    content: message
                }
            ],
            max_tokens: 300,
            temperature: 0.7
        });

        const reply = completion.choices[0]?.message?.content || "I'm sorry, I couldn't process that. Please try again.";
        res.json({ reply });

    } catch (error) {
        console.error("Groq API error:", error.message);
        res.status(500).json({ error: "AI service temporarily unavailable. Please try again." });
    }
};

exports.analyzeSymptoms = async (req, res) => {
    const { symptoms } = req.body;

    if (!symptoms) {
        return res.status(400).json({ error: "Symptoms are required" });
    }

    try {
        const completion = await groq.chat.completions.create({
            model: "llama-3.1-8b-instant",
            messages: [
                {
                    role: "system",
                    content: `You are a medical triage assistant. Analyze patient symptoms and respond ONLY in this exact JSON format (no extra text):
{
  "specialization": "Type of specialist doctor",
  "severity": "Low | Medium | High",
  "advice": "One short sentence of immediate advice",
  "warning": "Emergency warning or empty string"
}`
                },
                {
                    role: "user",
                    content: `Patient symptoms: ${symptoms}`
                }
            ],
            max_tokens: 150,
            temperature: 0.3
        });

        const text = completion.choices[0]?.message?.content || "{}";
        try {
            const result = JSON.parse(text);
            res.json(result);
        } catch {
            res.json({
                specialization: "General Physician",
                severity: "Low",
                advice: "Please consult a general physician for a proper evaluation.",
                warning: ""
            });
        }

    } catch (error) {
        console.error("Groq symptom analysis error:", error.message);
        res.status(500).json({ error: "AI service temporarily unavailable." });
    }
};
