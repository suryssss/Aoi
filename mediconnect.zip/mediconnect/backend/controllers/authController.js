const User = require("../models/User");
const Doctor = require("../models/Doctor");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
  let { name, email, password, user_type, age, gender, state, city, specialization, experience, qualifications } = req.body;

  if (email) email = email.trim().toLowerCase();
  const hashed = await bcrypt.hash(password, 10);

  try {
    const newUser = await User.create({
      name,
      email,
      password: hashed,
      role: user_type,
      age: user_type === "patient" ? age : undefined,
      gender: user_type === "patient" ? gender : undefined,
      state,
      city
    });

    if (user_type === "doctor") {
      await Doctor.create({
        name,
        email,
        specialization,
        experience: experience || 0,
        state,
        city,
        qualifications,
        location: `${city}, ${state}`,
        rating: 0,
        language: "English"
      });
    }

    res.json({ message: "User Registered Successfully" });
  } catch (error) {
    console.error(error);
    res.status(400).json({ message: "Email already exists or error saving data" });
  }
};

exports.login = async (req, res) => {
  let { email, password } = req.body;

  if (email) email = email.trim().toLowerCase();

  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ message: "User not found" });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).json({ message: "Invalid password" });

  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);

  let doctorDetails = null;
  if(user.role === "doctor") {
      doctorDetails = await Doctor.findOne({ email: user.email });
      if(!doctorDetails) doctorDetails = await Doctor.findOne({ name: user.name }); // fallback for older accounts
  }

  res.json({
    token,
    role: user.role,
    name: user.name,
    state: user.state,
    city: user.city,
    age: user.age,
    gender: user.gender,
    doctorDetails
  });
};
