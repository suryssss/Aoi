const SymptomHistory = require("../models/SymptomHistory");

exports.analyzeSymptoms = async (req, res) => {
    const { symptoms } = req.body;

    let specialization = "General Physician";
    let severity = "Normal";

    const text = symptoms.toLowerCase();

    // Cardiologist
    if (
        text.includes("chest pain") ||
        text.includes("heart") ||
        text.includes("shortness of breath") ||
        text.includes("palpitations")
    ) {
        specialization = "Cardiologist";
    }

    // Dermatologist
    else if (
        text.includes("skin") ||
        text.includes("rash") ||
        text.includes("acne") ||
        text.includes("itching")
    ) {
        specialization = "Dermatologist";
    }

    // Orthopedic
    else if (
        text.includes("bone") ||
        text.includes("fracture") ||
        text.includes("joint pain") ||
        text.includes("back pain")
    ) {
        specialization = "Orthopedic";
    }

    // ENT
    else if (
        text.includes("ear pain") ||
        text.includes("nose blockage") ||
        text.includes("throat pain")
    ) {
        specialization = "ENT Specialist";
    }

    // Severity Detection
    if (
        text.includes("severe") ||
        text.includes("unbearable") ||
        text.includes("emergency") ||
        text.includes("bleeding")
    ) {
        severity = "High";
    }

    // Save symptom history in database
    await SymptomHistory.create({
        symptoms,
        specialization,
        severity,
        date: new Date()
    });

    res.json({ specialization, severity });
};
