const mongoose = require("mongoose");

const doctorSchema = new mongoose.Schema({
    name: String,
    email: String,
    specialization: String,
    experience: Number,
    rating: Number,
    language: String,
    location: String,
    state: String,
    city: String,
    qualifications: String,
    image: String
});

module.exports = mongoose.model("Doctor", doctorSchema);
