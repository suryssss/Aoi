const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema({
  patientName: String,
  doctorName: String,
  date: String,
  time: String,
  prescription: { type: String, default: "" },
  medicines: [{
    name: String,
    time: String // Format: HH:MM
  }],
  feedback: {
    rating: { type: Number, min: 1, max: 5 },
    review: { type: String }
  }
}, { timestamps: true });

module.exports = mongoose.model("Appointment", appointmentSchema);
