const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  role: { type: String, default: "patient" },
  age: String,
  gender: String,
  state: String,
  city: String
}, { timestamps: true });

module.exports = mongoose.model("User", userSchema);
