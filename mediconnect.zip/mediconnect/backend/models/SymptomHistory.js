const mongoose = require("mongoose");

const symptomHistorySchema = new mongoose.Schema({
    symptoms: String,
    specialization: String,
    severity: String,
    date: Date
});

module.exports = mongoose.model("SymptomHistory", symptomHistorySchema);
