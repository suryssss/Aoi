const Doctor = require("../models/Doctor");

// Get all doctors
exports.getDoctors = async (req, res) => {
    try {
        const doctors = await Doctor.find();
        res.json(doctors);
    } catch (error) {
        res.status(500).json({ message: "Error fetching doctors" });
    }
};
