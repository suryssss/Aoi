/* MediConnect Chatbot Widget - include on every page */

const chatbotHTML = `
<button class="chatbot-fab" id="chatFab" title="Talk to MediBot AI">🤖</button>
<div class="chatbot-window" id="chatWindow">
  <div class="chat-header">
    <span class="bot-avatar">🤖</span>
    <div class="bot-info">
      <h4>MediBot AI</h4>
      <p>Powered by Groq · Always available</p>
    </div>
    <button class="chat-close" id="chatClose">✕</button>
  </div>
  <div class="chat-messages" id="chatMessages">
    <div class="chat-message bot">
      <div class="message-bubble">
        👋 Hi! I'm <strong>MediBot</strong>, your AI health assistant.<br><br>
        I can help you understand symptoms, suggest specialists, and answer health questions.<br><br>
        <em>Note: I'm not a replacement for professional medical advice.</em>
      </div>
    </div>
  </div>
  <div class="chat-input-area">
    <input type="text" id="chatInput" placeholder="Ask me about symptoms or health..." />
    <button class="chat-send-btn" id="chatSend">➤</button>
  </div>
</div>
`;

document.addEventListener("DOMContentLoaded", () => {
    document.body.insertAdjacentHTML("beforeend", chatbotHTML);

    const fab    = document.getElementById("chatFab");
    const win    = document.getElementById("chatWindow");
    const close  = document.getElementById("chatClose");
    const input  = document.getElementById("chatInput");
    const send   = document.getElementById("chatSend");
    const msgs   = document.getElementById("chatMessages");

    fab.addEventListener("click", () => win.classList.toggle("open"));
    close.addEventListener("click", () => win.classList.remove("open"));

    send.addEventListener("click", sendMessage);
    input.addEventListener("keydown", e => { if (e.key === "Enter") sendMessage(); });

    function appendMessage(role, text) {
        const div = document.createElement("div");
        div.className = `chat-message ${role}`;
        div.innerHTML = `<div class="message-bubble">${text}</div>`;
        msgs.appendChild(div);
        msgs.scrollTop = msgs.scrollHeight;
        return div;
    }

    function showTyping() {
        const div = document.createElement("div");
        div.className = "chat-message bot";
        div.id = "typing";
        div.innerHTML = `<div class="message-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>`;
        msgs.appendChild(div);
        msgs.scrollTop = msgs.scrollHeight;
    }

    function removeTyping() {
        const t = document.getElementById("typing");
        if (t) t.remove();
    }

    async function sendMessage() {
        const text = input.value.trim();
        if (!text) return;

        appendMessage("user", text);
        input.value = "";
        showTyping();
        send.disabled = true;

        try {
            const res = await fetch("http://localhost:5000/api/ai/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message: text })
            });

            const data = await res.json();
            removeTyping();

            if (res.ok) {
                appendMessage("bot", data.reply.replace(/\n/g, "<br>"));
            } else {
                appendMessage("bot", "⚠️ " + (data.error || "Something went wrong. Please try again."));
            }
        } catch {
            removeTyping();
            appendMessage("bot", "⚠️ Cannot connect to the server. Please make sure the backend is running.");
        } finally {
            send.disabled = false;
            input.focus();
        }
    }
});
